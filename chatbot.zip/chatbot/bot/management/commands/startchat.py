import logging
from django.core.management.base import BaseCommand
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.trainers import ListTrainer

# Suppress warnings that ChatterBot often generates during training and use
logging.basicConfig(level=logging.ERROR)

class Command(BaseCommand):
    """
    Django management command to start the Q&A Chatbot in the terminal.
    
    This allows the user to run the bot using the standard Django command: 
    python3 manage.py startchat
    
    The command initializes the bot, trains it, and enters a continuous 
    input loop for terminal interaction.
    """
    help = 'Starts a simple Q&A chat session with the ChatterBot.'

    def handle(self, *args, **options):
        # 1. Initialize the ChatBot
        try:
            self.stdout.write(self.style.SUCCESS("Initializing Simple Q&A Chatbot..."))
            
            # Initialize the bot object, connecting to the SQLite database defined in settings.py
            chatbot = ChatBot(
                'Simple Q&A Bot',
                storage_adapter='chatterbot.storage.SQLStorageAdapter',
                # Use the default database location created by Django
                database_uri='sqlite:///db.sqlite3' 
            )

            # 2. Train the Bot (This only runs fully the first time it sees new data)
            
            # Trainer for the large, general-purpose English corpus
            corpus_trainer = ChatterBotCorpusTrainer(chatbot)
            self.stdout.write("Training with English Corpus (for general knowledge)...")
            corpus_trainer.train("chatterbot.corpus.english")
            
            # Trainer for the custom Q&A list (for specific assignment requirements)
            custom_conversation = [
                # Required conversation flow from the prompt (Q&A/greeting)
                "Good morning! How are you doing?",
                "I am doing very well, thank you for asking.",
                "You're welcome.",
                "Do you like hats?", 

                # Additional custom Q&A to show list training capability
                "What is Artificial Intelligence?",
                "Artificial Intelligence (AI) is the simulation of human intelligence processes by machines, especially computer systems.",
                "What is machine learning?",
                "Machine learning (ML) is an application of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed.",
                "Who created you?",
                "I am a software program created using Python and the ChatterBot library."
            ]
            
            list_trainer = ListTrainer(chatbot)
            self.stdout.write("Training with Custom Q&A List (for specific responses)...")
            list_trainer.train(custom_conversation)

            self.stdout.write(self.style.SUCCESS("\n--- Chatbot is Ready! Type 'quit' to exit. ---\n"))
            
            # 3. Start the Chat Loop
            while True:
                try:
                    # Get user input from the command line
                    user_input = input("User: ")
                    
                    # Check for exit condition
                    if user_input.lower() in ['quit', 'exit', 'bye']:
                        self.stdout.write(self.style.NOTICE("\nChatbot session ended. Goodbye!"))
                        break
                    
                    # Get and display the bot's response
                    response = chatbot.get_response(user_input)
                    self.stdout.write(f"Bot: {response}")
                
                except (EOFError, KeyboardInterrupt):
                    # Handle Ctrl+C or end-of-file input
                    self.stdout.write(self.style.NOTICE("\nChatbot session interrupted. Goodbye!"))
                    break
                except Exception as e:
                    # Catch and report any unexpected runtime errors
                    self.stdout.write(self.style.ERROR(f"An unexpected error occurred during chat: {e}"))
                    break

        except Exception as e:
            # Handle errors during initial setup/training
            self.stdout.write(self.style.ERROR(f"\n--- FATAL INITIALIZATION ERROR ---\n{e}\n"))
            self.stdout.write(self.style.ERROR("Please check your database or package installations."))
